/**
 * 毎朝 自動要約レポート メール送信 — レシピ9対応 / PRO特典
 * 指定シートの当日分データをAIが要約し、毎朝メールで届ける。
 *
 * 導入手順：
 *  1)「拡張機能」→「Apps Script」に 3_ai_batch.gs（askAI関数）と一緒に置く
 *     ※ このファイルは askAI() を使うので、3_ai_batch.gs も同じプロジェクトに貼ること
 *  2) 下の RCONFIG を設定
 *  3) 一度 手動で dailyReport を実行して動作確認（初回は権限承認が必要）
 *  4) 左メニュー「トリガー」→ 時間主導型 → 日タイマー → 午前7〜8時 に dailyReport を設定
 *
 * 安全メモ：送信先はまず自分だけでテスト。外部への自動送信は誤送信に注意。
 */

const RCONFIG = {
  SHEET_NAME: 'log',                 // 集計対象シート名
  DATE_COL: 1,                       // 日付が入っている列（A列=1）。当日分のみ対象にする
  MAIL_TO: 'you@example.com',        // 送信先（複数はカンマ区切り）
  SUBJECT_PREFIX: '【日次サマリー】',
  SUMMARY_INSTRUCTION: '以下の当日データを、経営者が30秒で把握できるよう「要点3つ＋注意すべき点1つ」に要約して。誇張はしない。'
};

function dailyReport() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(RCONFIG.SHEET_NAME);
  if (!sheet) { throw new Error('シートが見つかりません: ' + RCONFIG.SHEET_NAME); }

  const values = sheet.getDataRange().getValues();
  const header = values[0];
  const today = _ymd(new Date());
  const rows = values.slice(1).filter(r => _ymd(new Date(r[RCONFIG.DATE_COL - 1])) === today);

  const subject = RCONFIG.SUBJECT_PREFIX + today;
  if (rows.length === 0) {
    MailApp.sendEmail(RCONFIG.MAIL_TO, subject, '本日の対象データはありませんでした。');
    return;
  }

  const table = [header].concat(rows).map(r => r.join(' | ')).join('\n').slice(0, 6000);
  const summary = askAI(RCONFIG.SUMMARY_INSTRUCTION + '\n\nデータ:\n' + table);  // ← 3_ai_batch.gs の関数
  MailApp.sendEmail(RCONFIG.MAIL_TO, subject, summary + '\n\n---\n（このメールは自動送信です）');
}

function _ymd(d) {
  // 空白・不正な日付は当日分の対象外にする。
  if (!Number.isFinite(d.getTime())) return '';
  return Utilities.formatDate(d, Session.getScriptTimeZone(), 'yyyy-MM-dd');
}
