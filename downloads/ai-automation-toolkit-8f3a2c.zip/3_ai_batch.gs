/**
 * AI一括処理ツール（スプレッドシート用）— レシピ8対応 / PRO特典
 * 非エンジニア向け：値の変更は「設定」ブロックだけでOK。
 *
 * できること：A列のテキストを1行ずつAIに処理させ、B列に結果を書き込む。
 *   例）問い合わせの分類、要約、翻訳、タグ付け、感情判定 など。
 *
 * 導入手順：
 *  1) スプレッドシートを開く →「拡張機能」→「Apps Script」
 *  2) このファイルの中身を全部貼り付けて保存
 *  3) 下の CONFIG.API_KEY に自分のOpenAI APIキーを入れる
 *     （キーはこのスクリプト内のみ。絶対に他人へ共有・公開しない）
 *  4) シートに戻ると「AIツール」メニューが出る → 「A列をB列へ一括処理」
 *
 * 安全メモ：
 *  - まず数行で試す。従量課金（gpt-4o-miniは非常に安価だが0円ではない）。
 *  - 個人情報・機密は規約を確認のうえ、必要ならダミー化してから。
 */

const CONFIG = {
  API_KEY: 'ここにOpenAI APIキー(sk-...)',   // ← ここだけ変更
  MODEL: 'gpt-4o-mini',                        // 安価で十分。精度重視なら 'gpt-4o'
  // AIへの指示。{input} が各行のA列テキストに置き換わる。用途に合わせて書き換える。
  INSTRUCTION: '次の問い合わせを「クレーム / 質問 / 要望 / その他」のいずれか一語だけで分類して: {input}',
  INPUT_COL: 1,     // A列 = 入力
  OUTPUT_COL: 2,    // B列 = 出力
  START_ROW: 2,     // 1行目は見出しとして飛ばす
  MAX_ROWS: 200,    // 一度に処理する最大行数（暴走防止）
  TEMPERATURE: 0
};

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('AIツール')
    .addItem('A列をB列へ一括処理', 'batchProcess')
    .addToUi();
}

function batchProcess() {
  const sheet = SpreadsheetApp.getActiveSheet();
  const last = Math.min(sheet.getLastRow(), CONFIG.START_ROW + CONFIG.MAX_ROWS - 1);
  if (last < CONFIG.START_ROW) { _toast('処理する行がありません'); return; }

  let done = 0, skipped = 0;
  for (let row = CONFIG.START_ROW; row <= last; row++) {
    const input = sheet.getRange(row, CONFIG.INPUT_COL).getValue();
    const existing = sheet.getRange(row, CONFIG.OUTPUT_COL).getValue();
    if (!input || existing) { skipped++; continue; }   // 空行・処理済みは飛ばす（再実行しても安全）
    try {
      const out = askAI(CONFIG.INSTRUCTION.replace('{input}', String(input)));
      sheet.getRange(row, CONFIG.OUTPUT_COL).setValue(out);
      done++;
      Utilities.sleep(300);   // レート制限対策
    } catch (e) {
      sheet.getRange(row, CONFIG.OUTPUT_COL).setValue('ERROR: ' + e.message);
    }
  }
  _toast(`完了：処理 ${done} 件 / スキップ ${skipped} 件`);
}

function askAI(prompt) {
  if (!CONFIG.API_KEY || CONFIG.API_KEY.indexOf('sk-') !== 0) {
    throw new Error('APIキーが未設定です。CONFIG.API_KEY を設定してください。');
  }
  const res = UrlFetchApp.fetch('https://api.openai.com/v1/chat/completions', {
    method: 'post',
    contentType: 'application/json',
    headers: { Authorization: 'Bearer ' + CONFIG.API_KEY },
    payload: JSON.stringify({
      model: CONFIG.MODEL,
      messages: [{ role: 'user', content: prompt }],
      temperature: CONFIG.TEMPERATURE
    }),
    muteHttpExceptions: true
  });
  const code = res.getResponseCode();
  const body = JSON.parse(res.getContentText() || '{}');
  if (code !== 200) throw new Error((body.error && body.error.message) || ('HTTP ' + code));
  return body.choices[0].message.content.trim();
}

function _toast(msg) { SpreadsheetApp.getActiveSpreadsheet().toast(msg, 'AIツール', 5); }
