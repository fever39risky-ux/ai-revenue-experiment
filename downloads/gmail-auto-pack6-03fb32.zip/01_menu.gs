// Gmail自動化GAS 6本セット — メニューと定期実行の管理
// スプレッドシートを開くと上部に「Gmail自動化」メニューが出ます。
// 各機能の設定は 02〜07 のファイル先頭の定数で変更してください。

const FEATURES = [
  { fn: 'saveAttachments', name: '添付ファイルをDriveに自動保存', every: { hours: 1 } },
  { fn: 'notifyNewMail',   name: '新着メールをSlack/Google Chatに通知', every: { minutes: 5 } },
  { fn: 'cleanupGmail',    name: '古いメールを自動整理', every: { dailyAt: 3 } },
  { fn: 'sortBySender',    name: '送信元で自動ラベル', every: { hours: 1 } },
  { fn: 'exportMails',     name: 'メールをシートに書き出し', every: { hours: 1 } },
  { fn: 'remindUnreplied', name: '未返信メールを毎朝リマインド', every: { dailyAt: 9 } },
];

function onOpen() {
  const ui = SpreadsheetApp.getUi();
  const menu = ui.createMenu('Gmail自動化');
  FEATURES.forEach((f, i) => menu.addItem('今すぐ実行: ' + f.name, 'run' + i));
  menu.addSeparator();
  FEATURES.forEach((f, i) => menu.addItem('定期実行 ON/OFF: ' + f.name, 'toggle' + i));
  menu.addSeparator()
    .addItem('定期実行の状態を確認', 'showStatus')
    .addItem('初期シートを作る（ルール・保存ログ・メール一覧）', 'setupSheets')
    .addItem('定期実行をすべて止める', 'removeAllTriggers')
    .addToUi();
}

// メニューからは引数を渡せないため番号ごとの入口を用意（末尾_の関数はメニューから呼べないので付けない）
function run0() { runFeature_(0); }  function toggle0() { toggleTrigger_(0); }
function run1() { runFeature_(1); }  function toggle1() { toggleTrigger_(1); }
function run2() { runFeature_(2); }  function toggle2() { toggleTrigger_(2); }
function run3() { runFeature_(3); }  function toggle3() { toggleTrigger_(3); }
function run4() { runFeature_(4); }  function toggle4() { toggleTrigger_(4); }
function run5() { runFeature_(5); }  function toggle5() { toggleTrigger_(5); }

function runFeature_(i) {
  const f = FEATURES[i];
  globalThis[f.fn]();
  SpreadsheetApp.getActive().toast(f.name + ' を実行しました（詳細は「実行数」のログ）', 'Gmail自動化', 5);
}

// 同じ関数のトリガーは常に1つだけにする（ONを2回押しても二重に動かない）
function toggleTrigger_(i) {
  const f = FEATURES[i];
  const existing = ScriptApp.getProjectTriggers().filter(t => t.getHandlerFunction() === f.fn);
  if (existing.length) {
    existing.forEach(t => ScriptApp.deleteTrigger(t));
    SpreadsheetApp.getActive().toast(f.name + ' の定期実行を止めました', 'Gmail自動化', 5);
    return false;
  }
  const b = ScriptApp.newTrigger(f.fn).timeBased();
  if (f.every.minutes) b.everyMinutes(f.every.minutes);
  else if (f.every.hours) b.everyHours(f.every.hours);
  else b.everyDays(1).atHour(f.every.dailyAt);
  b.create();
  SpreadsheetApp.getActive().toast(f.name + ' の定期実行を始めました（' + describe_(f.every) + '）', 'Gmail自動化', 5);
  return true;
}

function describe_(e) {
  return e.minutes ? e.minutes + '分ごと' : e.hours ? e.hours + '時間ごと' : '毎日' + e.dailyAt + '時台';
}

function showStatus() {
  const on = new Set(ScriptApp.getProjectTriggers().map(t => t.getHandlerFunction()));
  const lines = FEATURES.map(f => (on.has(f.fn) ? '● ON  ' : '○ OFF ') + f.name + (on.has(f.fn) ? '（' + describe_(f.every) + '）' : ''));
  SpreadsheetApp.getUi().alert('定期実行の状態', lines.join('\n'), SpreadsheetApp.getUi().ButtonSet.OK);
  return lines;
}

function removeAllTriggers() {
  const fns = new Set(FEATURES.map(f => f.fn));
  ScriptApp.getProjectTriggers().filter(t => fns.has(t.getHandlerFunction())).forEach(t => ScriptApp.deleteTrigger(t));
  SpreadsheetApp.getActive().toast('このセットの定期実行をすべて止めました', 'Gmail自動化', 5);
}

// 送信元ラベル用の「ルール」シートと、ログ用シートを作る（既にあれば何もしない）
function setupSheets() {
  const ss = SpreadsheetApp.getActive();
  if (!ss.getSheetByName(LBL_SHEET_NAME)) {
    const sh = ss.insertSheet(LBL_SHEET_NAME);
    sh.getRange(1, 1, 3, 3).setValues([
      ['送信元（アドレス or ドメイン）', 'ラベル名', '受信トレイから外す(TRUE/FALSE)'],
      ['billing@example.com', '請求書', false],
      ['example.co.jp', '取引先/例', false],
    ]);
    sh.setFrozenRows(1);
  }
  logSheet_();
  sheet_();
  ss.toast('初期シートを用意しました。「ルール」シートの例の行を自分の送信元に書き換えてください', 'Gmail自動化', 8);
}
