const RPL_QUERY = 'in:inbox -category:promotions -category:social -category:updates newer_than:14d';
const RPL_WAIT_HOURS = 24;                 // 最後のメールからこの時間たっても返信がなければ対象
const RPL_SKIP_FROM = /no-?reply|mailer-daemon|notification|magazine|newsletter/i;
const RPL_SKIP_LABEL = '返信不要';          // このラベルを付けたスレッドは対象外
const RPL_MARK_LABEL = '要返信';            // 未返信のスレッドに自動で付けるラベル（空文字なら付けない）

function remindUnreplied() {
  const me = [Session.getActiveUser().getEmail()].concat(GmailApp.getAliases())
    .map(s => s.toLowerCase());
  const now = Date.now();
  const mark = RPL_MARK_LABEL ? (GmailApp.getUserLabelByName(RPL_MARK_LABEL) || GmailApp.createLabel(RPL_MARK_LABEL)) : null;
  const pending = [];
  for (const th of GmailApp.search(RPL_QUERY + ' -label:' + RPL_SKIP_LABEL, 0, 200)) {
    const msgs = th.getMessages();
    const last = msgs[msgs.length - 1];
    const from = addr_(last.getFrom());
    const hours = (now - last.getDate().getTime()) / 3600000;
    const mine = me.includes(from);
    if (mine || RPL_SKIP_FROM.test(from) || hours < RPL_WAIT_HOURS) {
      if (mine && mark) th.removeLabel(mark);  // 返信済みになったらラベルを外す
      continue;
    }
    if (mark) th.addLabel(mark);
    pending.push({ hours, from, subject: last.getSubject() || '(件名なし)', id: th.getId() });
  }
  if (!pending.length) return;
  pending.sort((a, b) => b.hours - a.hours);   // 古いものから
  const rows = pending.map(p =>
    '<li>' + Math.floor(p.hours / 24) + '日' + Math.floor(p.hours % 24) + '時間 · ' +
    esc_(p.from) + ' · <a href="https://mail.google.com/mail/u/0/#all/' + p.id + '">' +
    esc_(p.subject) + '</a></li>').join('');
  GmailApp.sendEmail(me[0], '【未返信 ' + pending.length + '件】返信待ちのメール', 
    pending.map(p => p.from + ' / ' + p.subject).join('\n'),
    { htmlBody: '<p>返信していないメールが ' + pending.length + ' 件あります（古い順）。</p><ul>' + rows + '</ul>' });
}

// "山田 <yamada@example.com>" -> "yamada@example.com"
function addr_(s) {
  const m = String(s).match(/<([^>]+)>/);
  return (m ? m[1] : String(s)).trim().toLowerCase();
}

// 件名・送信元は外部の文字列なので、HTMLとして解釈されないようにする
function esc_(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
