const ATT_QUERY = 'has:attachment newer_than:3d -in:chats'; // 例: 'from:(billing@example.com) has:attachment newer_than:3d'
const ATT_FOLDER_ID = 'ここに保存先フォルダのID';
const ATT_EXT_OK = ['pdf', 'xlsx', 'xls', 'csv', 'docx', 'doc', 'zip', 'jpg', 'jpeg', 'png'];
const ATT_MIN_BYTES = 5 * 1024;          // 署名画像などの小さいファイルは保存しない
const ATT_LOG_SHEET = '保存ログ';
const ATT_LIMIT_MS = 4.5 * 60 * 1000;    // 6分の実行上限の手前で止める

function saveAttachments() {
  const start = Date.now();
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(10 * 1000)) return;
  try {
    const log = logSheet_();
    const done = new Set(log.getLastRow() > 1
      ? log.getRange(2, 1, log.getLastRow() - 1, 1).getValues().map(r => String(r[0]))
      : []);
    const folder = DriveApp.getFolderById(ATT_FOLDER_ID);
    const threads = GmailApp.search(ATT_QUERY, 0, 50);
    for (const th of threads) {
      for (const msg of th.getMessages()) {
        if (Date.now() - start > ATT_LIMIT_MS) return; // 残りは次回の実行で
        const id = msg.getId();
        if (done.has(id)) continue;             // 返信がついたスレッドでも新着分だけ処理
        const day = Utilities.formatDate(msg.getDate(), 'Asia/Tokyo', 'yyyyMMdd');
        const from = msg.getFrom().replace(/.*<|>.*/g, '').trim();
        const saved = [];
        for (const att of msg.getAttachments({ includeInlineImages: false })) {
          const name = att.getName() || 'noname';
          const ext = (name.split('.').pop() || '').toLowerCase();
          if (!ATT_EXT_OK.includes(ext) || att.getSize() < ATT_MIN_BYTES) continue;
          const safe = (day + '_' + name).replace(/[\\/:*?"<>|]/g, '_').slice(0, 150);
          const file = folder.createFile(att.copyBlob().setName(safe));
          saved.push(file.getUrl());
        }
        log.appendRow([id, day, from, msg.getSubject().slice(0, 100),
          saved.length, saved.join('\n')]);
        done.add(id);
      }
    }
  } finally {
    lock.releaseLock();
  }
}

function logSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(ATT_LOG_SHEET);
  if (!sh) {
    sh = ss.insertSheet(ATT_LOG_SHEET);
    sh.appendRow(['メールID', '受信日', '送信元', '件名', '保存数', '保存先']);
    sh.setFrozenRows(1);
  }
  return sh;
}
