const CLN_DRY_RUN = true;                  // まずは true のまま実行し、ログで対象を確認する
const CLN_RULES = [                        // days: 最後のメッセージからこの日数が過ぎたスレッドが対象
  { name: 'プロモーション', query: 'category:promotions', days: 30, action: 'trash' },
  { name: 'SNS通知',       query: 'category:social',     days: 30, action: 'trash' },
  { name: '受信トレイ整理', query: 'in:inbox',            days: 90, action: 'archive' },
];
const CLN_PROTECT = ' -is:starred -label:保存';   // スター付きと「保存」ラベルは絶対に触らない
const CLN_BATCH = 100;                     // GmailApp の一括操作は1回100件まで
const CLN_TIME_LIMIT_MS = 4.5 * 60 * 1000; // 6分制限の手前で止め、続きは次回

function cleanupGmail() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(10000)) return;
  const start = Date.now();
  try {
    for (const r of CLN_RULES) {
      if (!(r.days >= 1)) throw new Error(r.name + ': days を1以上にしてください');
      const q = r.query + ' older_than:' + r.days + 'd' + CLN_PROTECT + (r.action === 'archive' ? ' in:inbox' : '');
      const cutoff = new Date(Date.now() - r.days * 86400000);
      let offset = 0, done = 0, sample = [];
      while (Date.now() - start < CLN_TIME_LIMIT_MS) {
        const threads = GmailApp.search(q, offset, CLN_BATCH);
        if (!threads.length) break;
        // 検索は「どれか1通が古い」スレッドも返すので、最後のやり取りが新しいものは除外
        const targets = threads.filter(t => t.getLastMessageDate() < cutoff);
        if (sample.length < 5) targets.slice(0, 5 - sample.length).forEach(t => sample.push(t.getFirstMessageSubject()));
        if (CLN_DRY_RUN) { done += targets.length; offset += threads.length; continue; }
        if (targets.length) {
          if (r.action === 'trash') GmailApp.moveThreadsToTrash(targets);
          else GmailApp.moveThreadsToArchive(targets);
        }
        done += targets.length;
        offset += threads.length - targets.length;  // 除外したぶんだけ次の検索位置をずらす
      }
      console.log((CLN_DRY_RUN ? '[お試し] ' : '') + r.name + ': ' + done + '件 ' +
        (r.action === 'trash' ? 'ゴミ箱へ' : 'アーカイブ') + ' 例: ' + sample.join(' / '));
    }
  } finally {
    lock.releaseLock();
  }
}
