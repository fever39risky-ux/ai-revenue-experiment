const NTF_QUERY = 'in:inbox -category:promotions -category:social -category:updates newer_than:2d';
const NTF_DONE_LABEL = '通知済み';          // 通知したスレッドに付けるラベル（二重通知の防止）
const NTF_SKIP_FROM = /no-?reply|mailer-daemon|newsletter|magazine/i;
const NTF_MAX_PER_RUN = 20;               // 1回の実行で通知する上限

function notifyNewMail() {
  const url = PropertiesService.getScriptProperties().getProperty('WEBHOOK_URL');
  if (!url) throw new Error('スクリプトプロパティ WEBHOOK_URL を設定してください');
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(10000)) return;     // 前回の実行が終わっていなければ何もしない
  try {
    const done = GmailApp.getUserLabelByName(NTF_DONE_LABEL) || GmailApp.createLabel(NTF_DONE_LABEL);
    const threads = GmailApp.search(NTF_QUERY + ' -label:' + NTF_DONE_LABEL, 0, NTF_MAX_PER_RUN).reverse(); // 古い順
    for (const th of threads) {
      const msgs = th.getMessages();
      const m = msgs[msgs.length - 1];
      if (NTF_SKIP_FROM.test(m.getFrom())) { th.addLabel(done); continue; }
      const text = '📩 新着メール\n' +
        '送信元: ' + clean_(m.getFrom(), 80) + '\n' +
        '件名: ' + clean_(m.getSubject() || '(件名なし)', 120) + '\n' +
        clean_(m.getPlainBody(), 200) + '\n' +
        'https://mail.google.com/mail/u/0/#all/' + th.getId();
      const res = UrlFetchApp.fetch(url, {
        method: 'post', contentType: 'application/json; charset=UTF-8',
        payload: JSON.stringify({ text: text }), muteHttpExceptions: true
      });
      if (res.getResponseCode() >= 300) {  // 失敗したらラベルを付けずに止め、次回もう一度送る
        console.warn('通知に失敗: HTTP ' + res.getResponseCode());
        break;
      }
      th.addLabel(done);
    }
  } finally {
    lock.releaseLock();
  }
}

// 外部から届いた文字列を、通知先でリンクやメンションとして解釈されない形に整える
function clean_(s, max) {
  const t = String(s).replace(/\s+/g, ' ').trim()
    .replace(/</g, '＜').replace(/>/g, '＞').replace(/&/g, '＆').replace(/@(channel|here|everyone|all)\b/gi, '＠$1');
  return t.length > max ? t.slice(0, max) + '…' : t;
}
