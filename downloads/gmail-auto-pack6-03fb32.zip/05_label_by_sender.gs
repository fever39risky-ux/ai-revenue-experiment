const LBL_DRY_RUN = true;                  // まずは true のまま実行し、ログで対象を確認する
const LBL_SHEET_NAME = 'ルール';            // A列: 送信元  B列: ラベル名  C列: 受信トレイから外す(TRUE/FALSE)
const LBL_LOOKBACK = 'newer_than:2d';      // 定期実行で見る範囲。過去のメールにも付けたい初回だけ '' にする
const LBL_BATCH = 100;                     // GmailApp の一括操作は1回100件まで
const LBL_TIME_LIMIT_MS = 4.5 * 60 * 1000; // 6分制限の手前で止め、続きは次回

function sortBySender() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(10000)) return;
  const start = Date.now();
  try {
    const rows = SpreadsheetApp.getActive().getSheetByName(LBL_SHEET_NAME).getDataRange().getValues().slice(1);
    for (const [rawSender, rawLabel, rawSkip] of rows) {
      const sender = String(rawSender).trim(), labelName = String(rawLabel).trim();
      if (!sender || !labelName) continue;
      // 空白や OR などが入ると検索式が広がるので、メールアドレス・ドメインの形だけ受け付ける
      if (!/^[A-Za-z0-9._%+\-]*@?[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$/.test(sender)) {
        console.warn('送信元の書き方が不正なのでスキップ: ' + sender); continue;
      }
      const skipInbox = rawSkip === true || String(rawSkip).toUpperCase() === 'TRUE';
      const q = 'from:(' + sender + ')' + (LBL_LOOKBACK ? ' ' + LBL_LOOKBACK : '');
      const label = LBL_DRY_RUN ? null : (GmailApp.getUserLabelByName(labelName) || GmailApp.createLabel(labelName));
      let offset = 0, labeled = 0, archived = 0;
      while (Date.now() - start < LBL_TIME_LIMIT_MS) {
        const threads = GmailApp.search(q, offset, LBL_BATCH);
        if (!threads.length) break;
        offset += threads.length;   // ラベルを付けても検索結果は変わらないので、そのまま次へ進む
        const todo = threads.filter(t => !t.getLabels().some(l => l.getName() === labelName));
        const toArchive = skipInbox ? todo.filter(t => t.isInInbox()) : [];
        labeled += todo.length; archived += toArchive.length;
        if (LBL_DRY_RUN) continue;
        if (todo.length) label.addToThreads(todo);
        if (toArchive.length) GmailApp.moveThreadsToArchive(toArchive);
      }
      console.log((LBL_DRY_RUN ? '[お試し] ' : '') + sender + ' → ' + labelName + ': ' + labeled + '件' +
        (skipInbox ? '（うち受信トレイから外す ' + archived + '件）' : ''));
      if (Date.now() - start >= LBL_TIME_LIMIT_MS) { console.log('時間切れ。続きは次回の実行で処理します'); break; }
    }
  } finally {
    lock.releaseLock();
  }
}
