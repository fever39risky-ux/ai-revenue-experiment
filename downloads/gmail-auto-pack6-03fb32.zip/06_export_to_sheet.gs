const EXP_QUERY = 'in:inbox newer_than:7d -in:chats'; // 例: 'from:(order@example.com) newer_than:7d'
const EXP_SHEET = 'メール一覧';
const EXP_BODY_CHARS = 300;               // 本文は先頭だけ（全文を貼るとシートが重くなる）
const EXP_LIMIT_MS = 4.5 * 60 * 1000;     // 6分の実行上限の手前で止める

function exportMails() {
  const start = Date.now();
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(10 * 1000)) return;
  try {
    const sh = sheet_();
    const done = new Set(sh.getLastRow() > 1
      ? sh.getRange(2, 1, sh.getLastRow() - 1, 1).getValues().map(r => String(r[0]))
      : []);
    const rows = [];
    const threads = GmailApp.search(EXP_QUERY, 0, 100);
    outer:
    for (const th of threads) {
      for (const msg of th.getMessages()) {
        if (Date.now() - start > EXP_LIMIT_MS) break outer; // 残りは次回の実行で
        const id = msg.getId();
        if (done.has(id)) continue;
        const body = msg.getPlainBody().replace(/\s+/g, ' ').trim().slice(0, EXP_BODY_CHARS);
        rows.push([id, msg.getDate(), safe_(msg.getFrom()), safe_(msg.getSubject()),
          safe_(body), msg.getAttachments({ includeInlineImages: false }).length,
          'https://mail.google.com/mail/u/0/#all/' + id]);
        done.add(id);
      }
    }
    if (rows.length) {
      rows.sort((a, b) => a[1] - b[1]);  // 古い順に追記
      sh.getRange(sh.getLastRow() + 1, 1, rows.length, rows[0].length).setValues(rows);
    }
  } finally {
    lock.releaseLock();
  }
}

// = + - @ で始まる文字は数式として実行されないよう先頭に ' を付ける
function safe_(s) {
  s = String(s || '');
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

function sheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(EXP_SHEET);
  if (!sh) {
    sh = ss.insertSheet(EXP_SHEET);
    sh.appendRow(['メールID', '受信日時', '送信元', '件名', '本文（先頭）', '添付数', 'Gmailで開く']);
    sh.setFrozenRows(1);
  }
  return sh;
}
